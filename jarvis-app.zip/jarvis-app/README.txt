JARVIS APP FOR ANDROID - INSTALL GUIDE
======================================

You need three things, all free except the API usage:
  1. A GitHub account (github.com) to host the app for free
  2. An Anthropic API key (console.anthropic.com > API Keys). Add a few dollars of credit.
  3. Your Android phone with Chrome

PART 1 - PUT THE APP ONLINE (about 5 minutes)
---------------------------------------------
The microphone only works on a secure https site, so the app needs a real address.
GitHub Pages gives you one for free.

 1. Sign in at github.com and create a new PUBLIC repository named "jarvis".
 2. Click "uploading an existing file" and upload everything from this folder:
    index.html, style.css, app.js, sw.js, manifest.webmanifest,
    and the whole "icons" folder (3 PNG files).
    Tip: on a phone, switch Chrome to "Desktop site" to get the upload button.
    It is easier from a computer if you have one.
 3. Click "Commit changes".
 4. Open Settings > Pages. Under "Branch" choose "main" and "/ (root)", then Save.
 5. Wait one minute. Your app address will be:
        https://YOUR-USERNAME.github.io/jarvis/

Your address is public, but your API key is never uploaded. It stays on your phone.

PART 2 - INSTALL ON YOUR PHONE
------------------------------
 1. Open your address in Chrome on your Android phone.
 2. Tap the menu (three dots) > "Install app" (or "Add to Home screen").
 3. Open Jarvis from your home screen. It runs full screen like a normal app.
 4. Tap SET, paste your API key, tap SAVE.
 5. Tap the mic and allow the microphone when Android asks.

WHAT IT CAN DO
--------------
 - Talk in Thai and English, spoken replies
 - Time, timers (they ring and vibrate), calculations
 - Weather for your location or any city
 - Buttons that open Google search, Maps, directions and YouTube
 - Hands-free: turn it on in SET, then say "Jarvis ..." while the app is open

LIMITS
------
 - It cannot launch other apps, call, text or read your phone data.
   Web apps are not allowed to do that on Android.
 - Hands-free only listens while the app is open on screen.
 - Android may show a mic indicator while hands-free is on, and it uses battery.

KEEP YOUR KEY SAFE
------------------
Anyone who has your phone with the app open could use your key. Set a monthly
spending limit in the Anthropic console, and delete the key there if the phone is lost.
